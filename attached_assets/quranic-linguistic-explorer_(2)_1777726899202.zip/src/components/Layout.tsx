import React from 'react';
import { Book, Search, Settings, User, Languages, Moon, Sun } from 'lucide-react';

interface LayoutProps {
  children: React.ReactNode;
  onSearch?: (query: string) => void;
  onOpenDictionary?: () => void;
  user?: any;
  onSignIn?: () => void;
  onSignOut?: () => void;
  fontSize?: number;
  onFontSizeChange?: (size: number) => void;
  isDarkMode?: boolean;
  onToggleDarkMode?: () => void;
}

export const Layout: React.FC<LayoutProps> = ({ 
  children, 
  onSearch, 
  onOpenDictionary,
  user, 
  onSignIn, 
  onSignOut,
  fontSize,
  onFontSizeChange,
  isDarkMode,
  onToggleDarkMode
}) => {
  return (
    <div className="min-h-screen bg-[var(--color-grove-cream)] text-[var(--color-grove-purple)] font-sans">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-[var(--color-grove-paper)]/80 backdrop-blur-md border-b border-[var(--color-grove-purple)]/10 px-4 py-3">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="bg-[var(--color-grove-green)] text-white p-2 rounded-lg shadow-sm">
              <Book size={20} />
            </div>
            <h1 className="text-xl font-bold tracking-tight text-[var(--color-grove-purple)]">Quranic Linguistic Explorer</h1>
          </div>

          <div className="flex items-center gap-4">
            {onSearch && (
              <div className="relative hidden lg:block">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-[var(--color-grove-purple)]/40" size={18} />
                <input
                  type="text"
                  placeholder="Search Surah..."
                  className="pl-10 pr-4 py-2 bg-[var(--color-grove-cream)] border-none rounded-full text-sm w-64 focus:ring-2 focus:ring-[var(--color-grove-green)]/20 transition-all text-[var(--color-grove-purple)] placeholder:[var(--color-grove-purple)]/40"
                  onChange={(e) => onSearch(e.target.value)}
                />
              </div>
            )}

            {onOpenDictionary && (
              <button
                onClick={onOpenDictionary}
                className="flex items-center gap-2 bg-[var(--color-grove-teal)]/10 text-[var(--color-grove-teal)] px-4 py-2 rounded-full text-sm font-bold hover:bg-[var(--color-grove-teal)]/20 transition-all"
                title="Global Dictionary"
              >
                <Languages size={18} />
                <span className="hidden sm:inline">Dictionary</span>
              </button>
            )}

            {onToggleDarkMode && (
              <button
                onClick={onToggleDarkMode}
                className="p-2 bg-[var(--color-grove-purple)]/5 text-[var(--color-grove-purple)] rounded-full hover:bg-[var(--color-grove-purple)]/10 transition-all"
                title={isDarkMode ? "Switch to Light Mode" : "Switch to Dark Mode"}
              >
                {isDarkMode ? <Sun size={18} /> : <Moon size={18} />}
              </button>
            )}

            {onFontSizeChange && fontSize !== undefined && (
              <div className="flex items-center gap-2 bg-[var(--color-grove-gold)]/10 px-3 py-1.5 rounded-full">
                <span className="text-[10px] font-bold uppercase tracking-wider text-[var(--color-grove-gold)]">Font</span>
                <input
                  type="range"
                  min="20"
                  max="64"
                  value={fontSize}
                  onChange={(e) => onFontSizeChange(parseInt(e.target.value))}
                  className="w-24 h-1 bg-[var(--color-grove-gold)]/20 rounded-lg appearance-none cursor-pointer accent-[var(--color-grove-gold)]"
                />
                <span className="text-xs font-mono w-6 text-[var(--color-grove-gold)]">{fontSize}</span>
              </div>
            )}

            {user ? (
              <div className="flex items-center gap-3">
                <button 
                  onClick={onSignOut}
                  className="text-sm font-bold text-[var(--color-grove-pink)] hover:text-[var(--color-grove-pink)]/80 transition-colors"
                >
                  Sign Out
                </button>
                <div className="w-8 h-8 bg-[var(--color-grove-cream)] rounded-full flex items-center justify-center overflow-hidden border border-[var(--color-grove-purple)]/10">
                  {user.photoURL ? (
                    <img src={user.photoURL} alt={user.displayName} className="w-full h-full object-cover" />
                  ) : (
                    <User size={16} className="text-[var(--color-grove-purple)]" />
                  )}
                </div>
              </div>
            ) : (
              <button
                onClick={onSignIn}
                className="bg-[var(--color-grove-purple)] text-white px-6 py-2 rounded-full text-sm font-bold hover:bg-[var(--color-grove-purple)]/90 transition-all shadow-md active:scale-95"
              >
                Sign In
              </button>
            )}
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 py-8">
        {children}
      </main>

      {/* Footer */}
      <footer className="border-t border-[var(--color-grove-purple)]/10 py-12 mt-20 bg-[var(--color-grove-paper)]">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <p className="text-sm font-medium text-[var(--color-grove-purple)]/60">
            © 2026 Quranic Linguistic Explorer. Powered by Gemini & AlQuran Cloud.
          </p>
        </div>
      </footer>
    </div>
  );
};
