import React, { Component, ErrorInfo, ReactNode } from 'react';

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

export class ErrorBoundary extends Component<Props, State> {
  public state: State = {
    hasError: false,
    error: null
  };

  public static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('Uncaught error:', error, errorInfo);
  }

  public render() {
    if (this.state.hasError) {
      let errorMessage = "Something went wrong.";
      let isFirestoreError = false;

      try {
        const parsed = JSON.parse(this.state.error?.message || "");
        if (parsed.error && parsed.operationType) {
          errorMessage = `Database Error: ${parsed.error} during ${parsed.operationType} on ${parsed.path}`;
          isFirestoreError = true;
        }
      } catch (e) {
        errorMessage = this.state.error?.message || errorMessage;
      }

      return (
        <div className="min-h-screen flex items-center justify-center bg-[var(--color-grove-cream)] p-4">
          <div className="bg-white p-8 rounded-[2rem] shadow-xl max-w-md w-full border border-[var(--color-grove-purple)]/10 text-center">
            <div className="w-16 h-16 bg-[var(--color-grove-pink)]/10 text-[var(--color-grove-pink)] rounded-full flex items-center justify-center mx-auto mb-6">
              <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
            </div>
            <h1 className="text-2xl font-bold text-[var(--color-grove-purple)] mb-4">Oops! Something went wrong</h1>
            <div className="bg-[var(--color-grove-cream)] p-4 rounded-xl mb-6 text-left">
              <p className="text-sm font-mono text-[var(--color-grove-purple)]/80 break-words">
                {errorMessage}
              </p>
            </div>
            {isFirestoreError && (
              <p className="text-xs text-[var(--color-grove-purple)]/60 mb-6">
                This might be due to missing permissions. Please ensure you are signed in and have access to this resource.
              </p>
            )}
            <button
              onClick={() => window.location.reload()}
              className="w-full bg-[var(--color-grove-purple)] text-white py-3 rounded-full font-bold hover:bg-[var(--color-grove-purple)]/90 transition-all"
            >
              Reload Application
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
