import React from 'react';
import { Surah } from '../types';
import { ChevronRight } from 'lucide-react';

interface SurahListProps {
  surahs: Surah[];
  onSelect: (surah: Surah) => void;
  selectedSurahNumber?: number;
}

export const SurahList: React.FC<SurahListProps> = ({ surahs, onSelect, selectedSurahNumber }) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
      {surahs.map((surah) => (
        <button
          key={surah.number}
          onClick={() => onSelect(surah)}
          className={`flex items-center justify-between p-5 rounded-2xl border transition-all text-left group
            ${selectedSurahNumber === surah.number 
              ? 'bg-grove-purple border-grove-purple text-white shadow-lg' 
              : 'bg-grove-paper border-grove-purple/10 hover:border-grove-green hover:shadow-md'
            }`}
        >
          <div className="flex items-center gap-4">
            <div className={`w-10 h-10 rounded-xl flex items-center justify-center font-mono text-sm font-bold
              ${selectedSurahNumber === surah.number ? 'bg-white/10' : 'bg-grove-cream text-grove-green'}`}>
              {surah.number}
            </div>
            <div>
              <h3 className="font-bold text-grove-purple group-hover:text-grove-green transition-colors">
                {selectedSurahNumber === surah.number ? <span className="text-white">{surah.englishName}</span> : surah.englishName}
              </h3>
              <p className={`text-[10px] font-bold uppercase tracking-wider ${selectedSurahNumber === surah.number ? 'text-white/60' : 'text-grove-purple/40'}`}>
                {surah.numberOfAyahs} Ayahs
              </p>
            </div>
          </div>
          <div className="flex flex-col items-end gap-1">
            <span className={`text-2xl font-arabic leading-none ${selectedSurahNumber === surah.number ? 'text-white' : 'text-grove-purple'}`}>{surah.name}</span>
            <ChevronRight size={16} className={`transition-transform group-hover:translate-x-1 ${selectedSurahNumber === surah.number ? 'text-white/40' : 'text-grove-gold'}`} />
          </div>
        </button>
      ))}
    </div>
  );
};
