import React, { useState } from 'react';
import { Ayah, Note } from '../types';
import { BookOpen, FileText, MessageSquare, Save, Loader2, X, Copy, Check, Languages } from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import { getAyahGrammarStream, getAyahMorphologyStream, getAyahDictionaryStream } from '../services/geminiService';
import { AnalysisCache } from '../services/cacheService';

interface AyahCardProps {
  ayah: Ayah;
  surahName: string;
  note?: Note;
  onSaveNote: (content: string) => Promise<void>;
  isAuthenticated: boolean;
  fontSize: number;
}

export const AyahCard: React.FC<AyahCardProps> = ({ 
  ayah, 
  surahName, 
  note, 
  onSaveNote, 
  isAuthenticated,
  fontSize
}) => {
  const [activeTabs, setActiveTabs] = useState<string[]>([]);
  const [activeTranslation, setActiveTranslation] = useState<'en' | 'ur' | 'ar' | 'none'>('en');
  const [grammarAnalysis, setGrammarAnalysis] = useState<string>('');
  const [morphologyAnalysis, setMorphologyAnalysis] = useState<string>('');
  const [dictionaryAnalysis, setDictionaryAnalysis] = useState<string>('');
  const [loadingStates, setLoadingStates] = useState<Record<string, boolean>>({});
  const [noteContent, setNoteContent] = useState(note?.content || '');
  const [isSavingNote, setIsSavingNote] = useState(false);
  const [isCopied, setIsCopied] = useState(false);
  const [copiedType, setCopiedType] = useState<string | null>(null);

  const handleCopy = (text: string, type?: string) => {
    navigator.clipboard.writeText(text);
    if (type) {
      setCopiedType(type);
      setTimeout(() => setCopiedType(null), 2000);
    } else {
      setIsCopied(true);
      setTimeout(() => setIsCopied(false), 2000);
    }
  };

  const toggleTab = (tab: string) => {
    setActiveTabs(prev => 
      prev.includes(tab) ? prev.filter(t => t !== tab) : [...prev, tab]
    );
  };

  const handleFetchAnalysis = async (type: 'grammar' | 'morphology' | 'dictionary') => {
    const isAlreadyActive = activeTabs.includes(type);
    toggleTab(type);
    
    if (isAlreadyActive) return;

    // Only fetch if not already fetched
    if (type === 'grammar' && grammarAnalysis) return;
    if (type === 'morphology' && morphologyAnalysis) return;
    if (type === 'dictionary' && dictionaryAnalysis) return;

    // Check local cache first
    const cached = AnalysisCache.get(type, surahName, ayah.numberInSurah);
    if (cached) {
      if (type === 'grammar') setGrammarAnalysis(cached);
      else if (type === 'morphology') setMorphologyAnalysis(cached);
      else if (type === 'dictionary') setDictionaryAnalysis(cached);
      return;
    }

    setLoadingStates(prev => ({ ...prev, [type]: true }));
    try {
      let fullText = '';
      const onChunk = (text: string) => {
        fullText = text;
        if (type === 'grammar') setGrammarAnalysis(text);
        else if (type === 'morphology') setMorphologyAnalysis(text);
        else if (type === 'dictionary') setDictionaryAnalysis(text);
      };

      if (type === 'grammar') {
        await getAyahGrammarStream(ayah.text, surahName, ayah.numberInSurah, onChunk);
      } else if (type === 'morphology') {
        await getAyahMorphologyStream(ayah.text, surahName, ayah.numberInSurah, onChunk);
      } else if (type === 'dictionary') {
        await getAyahDictionaryStream(ayah.text, surahName, ayah.numberInSurah, onChunk);
      }

      // Save to cache after successful fetch
      if (fullText) {
        AnalysisCache.set(type, surahName, ayah.numberInSurah, fullText);
      }
    } catch (error) {
      console.error(error);
      const errorMsg = 'Failed to fetch analysis. Please try again.';
      if (type === 'grammar') setGrammarAnalysis(errorMsg);
      else if (type === 'morphology') setMorphologyAnalysis(errorMsg);
      else if (type === 'dictionary') setDictionaryAnalysis(errorMsg);
    } finally {
      setLoadingStates(prev => ({ ...prev, [type]: false }));
    }
  };

  const handleSaveNote = async () => {
    setIsSavingNote(true);
    try {
      await onSaveNote(noteContent);
    } finally {
      setIsSavingNote(false);
    }
  };

  const analysisFontSize = Math.max(16, fontSize * 0.6);
  const notesFontSize = Math.max(14, fontSize * 0.5);

  return (
    <div className="bg-[var(--color-grove-paper)] border border-[var(--color-grove-purple)]/5 rounded-[2rem] overflow-hidden mb-8 transition-all hover:shadow-md">
      <div className="p-8 md:p-10">
        {/* Ayah Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-[var(--color-grove-cream)] flex items-center justify-center font-mono text-xs text-[var(--color-grove-green)] font-bold shadow-inner">
              {ayah.numberInSurah}
            </div>
            <button
              onClick={() => handleCopy(ayah.text)}
              className="p-2.5 hover:bg-[var(--color-grove-cream)] rounded-xl text-[var(--color-grove-purple)]/40 hover:text-[var(--color-grove-purple)] transition-all"
              title="Copy Ayah"
            >
              {isCopied ? <Check size={18} className="text-[var(--color-grove-green)]" /> : <Copy size={18} />}
            </button>
          </div>
          <div className="flex items-center gap-2 flex-wrap justify-end">
            <button
              onClick={() => handleFetchAnalysis('dictionary')}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-[10px] font-bold uppercase tracking-widest transition-all
                ${activeTabs.includes('dictionary') ? 'bg-[var(--color-grove-teal)] text-white shadow-md' : 'bg-[var(--color-grove-teal)]/10 text-[var(--color-grove-teal)] hover:bg-[var(--color-grove-teal)]/20'}`}
            >
              <Languages size={14} />
              Dictionary
            </button>
            <button
              onClick={() => handleFetchAnalysis('grammar')}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-[10px] font-bold uppercase tracking-widest transition-all
                ${activeTabs.includes('grammar') ? 'bg-[var(--color-grove-purple)] text-white shadow-md' : 'bg-[var(--color-grove-purple)]/10 text-[var(--color-grove-purple)] hover:bg-[var(--color-grove-purple)]/20'}`}
            >
              <BookOpen size={14} />
              Grammar
            </button>
            <button
              onClick={() => handleFetchAnalysis('morphology')}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-[10px] font-bold uppercase tracking-widest transition-all
                ${activeTabs.includes('morphology') ? 'bg-[var(--color-grove-gold)] text-white shadow-md' : 'bg-[var(--color-grove-gold)]/10 text-[var(--color-grove-gold)] hover:bg-[var(--color-grove-gold)]/20'}`}
            >
              <FileText size={14} />
              Morphology
            </button>
            <button
              onClick={() => toggleTab('notes')}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-[10px] font-bold uppercase tracking-widest transition-all
                ${activeTabs.includes('notes') ? 'bg-[var(--color-grove-pink)] text-white shadow-md' : 'bg-[var(--color-grove-pink)]/10 text-[var(--color-grove-pink)] hover:bg-[var(--color-grove-pink)]/20'}`}
            >
              <MessageSquare size={14} />
              Notes
            </button>
          </div>
        </div>

        {/* Ayah Text */}
        <div className="text-right mb-10">
          <p 
            className="font-arabic leading-[2] text-[var(--color-grove-purple)] dir-rtl"
            style={{ fontSize: `${fontSize}px` }}
          >
            {ayah.text}
          </p>
        </div>

        {/* Translation Section */}
        <div className="border-t border-[var(--color-grove-purple)]/5 pt-8">
          <div className="flex items-center gap-4 mb-6">
            <button 
              onClick={() => setActiveTranslation('en')}
              className={`text-[10px] font-bold uppercase tracking-widest px-3 py-1.5 rounded-lg transition-all ${activeTranslation === 'en' ? 'bg-[var(--color-grove-purple)] text-white shadow-sm' : 'text-[var(--color-grove-purple)]/40 hover:text-[var(--color-grove-purple)]'}`}
            >
              English
            </button>
            <button 
              onClick={() => setActiveTranslation('ur')}
              className={`text-[10px] font-bold uppercase tracking-widest px-3 py-1.5 rounded-lg transition-all ${activeTranslation === 'ur' ? 'bg-[var(--color-grove-purple)] text-white shadow-sm' : 'text-[var(--color-grove-purple)]/40 hover:text-[var(--color-grove-purple)]'}`}
            >
              Urdu
            </button>
            <button 
              onClick={() => setActiveTranslation('ar')}
              className={`text-[10px] font-bold uppercase tracking-widest px-3 py-1.5 rounded-lg transition-all ${activeTranslation === 'ar' ? 'bg-[var(--color-grove-purple)] text-white shadow-sm' : 'text-[var(--color-grove-purple)]/40 hover:text-[var(--color-grove-purple)]'}`}
            >
              Arabic (Tafsir)
            </button>
            <button 
              onClick={() => setActiveTranslation('none')}
              className={`text-[10px] font-bold uppercase tracking-widest px-3 py-1.5 rounded-lg transition-all ${activeTranslation === 'none' ? 'bg-[var(--color-grove-pink)] text-white shadow-sm' : 'text-[var(--color-grove-pink)]/40 hover:text-[var(--color-grove-pink)]'}`}
            >
              Hide
            </button>
          </div>

          {activeTranslation !== 'none' && (
            <div className={`animate-in fade-in slide-in-from-left-2 duration-300 ${activeTranslation === 'ur' || activeTranslation === 'ar' ? 'text-right dir-rtl font-arabic' : 'text-left'}`}>
              <p className={`text-[var(--color-grove-purple)]/80 leading-relaxed ${activeTranslation === 'ur' || activeTranslation === 'ar' ? 'text-2xl' : 'text-base font-medium'}`}>
                {activeTranslation === 'en' && ayah.translations?.en}
                {activeTranslation === 'ur' && ayah.translations?.ur}
                {activeTranslation === 'ar' && ayah.translations?.ar}
              </p>
              <p className="mt-4 text-[10px] text-[var(--color-grove-gold)] uppercase tracking-[0.2em] font-black">
                {activeTranslation === 'en' && "Sahih International"}
                {activeTranslation === 'ur' && "Fateh Muhammad Jalandhry"}
                {activeTranslation === 'ar' && "Tafsir al-Jalalayn"}
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Analysis/Notes Panels */}
      <div className="flex flex-col border-t border-[var(--color-grove-purple)]/5">
        {activeTabs.includes('grammar') && (
          <div className="bg-[var(--color-grove-purple)]/5 p-8 md:p-10 animate-in fade-in slide-in-from-top-2 duration-300 border-b border-[var(--color-grove-purple)]/5">
            <div className="flex items-center justify-between mb-6">
              <h4 className="text-xs font-black uppercase tracking-[0.2em] text-[var(--color-grove-purple)]">Arabic Grammar Analysis</h4>
              <div className="flex items-center gap-2">
                <button 
                  onClick={() => handleCopy(grammarAnalysis, 'grammar')} 
                  className="p-2 text-[var(--color-grove-purple)]/40 hover:text-[var(--color-grove-purple)] transition-all"
                  title="Copy Analysis"
                >
                  {copiedType === 'grammar' ? <Check size={18} className="text-[var(--color-grove-green)]" /> : <Copy size={18} />}
                </button>
                <button onClick={() => toggleTab('grammar')} className="text-[var(--color-grove-purple)]/40 hover:text-[var(--color-grove-purple)]">
                  <X size={20} />
                </button>
              </div>
            </div>
            {loadingStates['grammar'] ? (
              <div className="flex flex-col items-center justify-center py-12 gap-3">
                <Loader2 className="animate-spin text-[var(--color-grove-purple)]" size={24} />
                <p className="text-[10px] font-bold uppercase tracking-widest text-[var(--color-grove-purple)]/40">Analyzing with AI...</p>
              </div>
            ) : (
              <>
                <div 
                  className="markdown-body prose prose-sm max-w-none dir-rtl text-right font-arabic text-[var(--color-grove-purple)]"
                  style={{ fontSize: `${analysisFontSize}px` }}
                >
                  <ReactMarkdown>{grammarAnalysis}</ReactMarkdown>
                </div>
                <div className="mt-8 pt-4 border-t border-[var(--color-grove-purple)]/10 text-[10px] text-[var(--color-grove-purple)]/40 font-bold uppercase tracking-widest italic">
                  Analysis aligned with classical works including I'rab al-Quran by Al-Darwish and Al-Nahhas.
                </div>
              </>
            )}
          </div>
        )}

        {activeTabs.includes('dictionary') && (
          <div className="bg-[var(--color-grove-teal)]/5 p-8 md:p-10 animate-in fade-in slide-in-from-top-2 duration-300 border-b border-[var(--color-grove-purple)]/5">
            <div className="flex items-center justify-between mb-6">
              <h4 className="text-xs font-black uppercase tracking-[0.2em] text-[var(--color-grove-teal)]">Word Dictionary</h4>
              <div className="flex items-center gap-2">
                <button 
                  onClick={() => handleCopy(dictionaryAnalysis, 'dictionary')} 
                  className="p-2 text-[var(--color-grove-teal)]/40 hover:text-[var(--color-grove-teal)] transition-all"
                  title="Copy Dictionary"
                >
                  {copiedType === 'dictionary' ? <Check size={18} className="text-[var(--color-grove-green)]" /> : <Copy size={18} />}
                </button>
                <button onClick={() => toggleTab('dictionary')} className="text-[var(--color-grove-teal)]/40 hover:text-[var(--color-grove-teal)]">
                  <X size={20} />
                </button>
              </div>
            </div>
            {loadingStates['dictionary'] ? (
              <div className="flex flex-col items-center justify-center py-12 gap-3">
                <Loader2 className="animate-spin text-[var(--color-grove-teal)]" size={24} />
                <p className="text-[10px] font-bold uppercase tracking-widest text-[var(--color-grove-teal)]/40">Creating dictionary...</p>
              </div>
            ) : (
              <>
                <div 
                  className="markdown-body prose prose-sm max-w-none text-[var(--color-grove-purple)]"
                  style={{ fontSize: `${analysisFontSize}px` }}
                >
                  <ReactMarkdown>{dictionaryAnalysis}</ReactMarkdown>
                </div>
                <div className="mt-8 pt-4 border-t border-[var(--color-grove-teal)]/10 text-[10px] text-[var(--color-grove-teal)]/40 font-bold uppercase tracking-widest italic">
                  Definitions derived from Lisan al-Arab, Mu'jam Maqayis al-Lugha, and Lane's Lexicon.
                </div>
              </>
            )}
          </div>
        )}

        {activeTabs.includes('morphology') && (
          <div className="bg-[var(--color-grove-gold)]/5 p-8 md:p-10 animate-in fade-in slide-in-from-top-2 duration-300 border-b border-[var(--color-grove-purple)]/5">
            <div className="flex items-center justify-between mb-6">
              <h4 className="text-xs font-black uppercase tracking-[0.2em] text-[var(--color-grove-gold)]">Morphological Analysis</h4>
              <div className="flex items-center gap-2">
                <button 
                  onClick={() => handleCopy(morphologyAnalysis, 'morphology')} 
                  className="p-2 text-[var(--color-grove-gold)]/40 hover:text-[var(--color-grove-gold)] transition-all"
                  title="Copy Morphology"
                >
                  {copiedType === 'morphology' ? <Check size={18} className="text-[var(--color-grove-green)]" /> : <Copy size={18} />}
                </button>
                <button onClick={() => toggleTab('morphology')} className="text-[var(--color-grove-gold)]/40 hover:text-[var(--color-grove-gold)]">
                  <X size={20} />
                </button>
              </div>
            </div>
            {loadingStates['morphology'] ? (
              <div className="flex flex-col items-center justify-center py-12 gap-3">
                <Loader2 className="animate-spin text-[var(--color-grove-gold)]" size={24} />
                <p className="text-[10px] font-bold uppercase tracking-widest text-[var(--color-grove-gold)]/40">Analyzing with AI...</p>
              </div>
            ) : (
              <>
                <div 
                  className="markdown-body prose prose-sm max-w-none dir-rtl text-right font-arabic text-[var(--color-grove-purple)]"
                  style={{ fontSize: `${analysisFontSize}px` }}
                >
                  <ReactMarkdown>{morphologyAnalysis}</ReactMarkdown>
                </div>
                <div className="mt-8 pt-4 border-t border-[var(--color-grove-gold)]/10 text-[10px] text-[var(--color-grove-gold)]/40 font-bold uppercase tracking-widest italic">
                  Morphological data follows classical Sarf methodology of Ibn Jinni and Al-Hamalawy.
                </div>
              </>
            )}
          </div>
        )}

        {activeTabs.includes('notes') && (
          <div className="bg-[var(--color-grove-pink)]/5 p-8 md:p-10 animate-in fade-in slide-in-from-top-2 duration-300">
            <div className="flex items-center justify-between mb-6">
              <h4 className="text-xs font-black uppercase tracking-[0.2em] text-[var(--color-grove-pink)]">Personal Notes</h4>
              <div className="flex items-center gap-2">
                <button 
                  onClick={() => handleCopy(noteContent, 'notes')} 
                  className="p-2 text-[var(--color-grove-pink)]/40 hover:text-[var(--color-grove-pink)] transition-all"
                  title="Copy Notes"
                >
                  {copiedType === 'notes' ? <Check size={18} className="text-[var(--color-grove-green)]" /> : <Copy size={18} />}
                </button>
                <button onClick={() => toggleTab('notes')} className="text-[var(--color-grove-pink)]/40 hover:text-[var(--color-grove-pink)]">
                  <X size={20} />
                </button>
              </div>
            </div>
            <div className="space-y-6">
              {!isAuthenticated && (
                <p className="text-xs font-bold uppercase tracking-widest text-[var(--color-grove-pink)] bg-[var(--color-grove-pink)]/10 p-4 rounded-2xl border border-[var(--color-grove-pink)]/20">
                  Please sign in to save your notes permanently.
                </p>
              )}
              <textarea
                value={noteContent}
                onChange={(e) => setNoteContent(e.target.value)}
                placeholder="Write your reflections or notes about this ayah..."
                className="w-full h-40 p-6 bg-[var(--color-grove-paper)] border border-[var(--color-grove-purple)]/10 rounded-3xl focus:ring-4 focus:ring-[var(--color-grove-pink)]/10 transition-all resize-none text-[var(--color-grove-purple)] placeholder:[var(--color-grove-purple)]/30"
                style={{ fontSize: `${notesFontSize}px` }}
              />
              <div className="flex justify-end">
                <button
                  onClick={handleSaveNote}
                  disabled={isSavingNote || !isAuthenticated}
                  className="flex items-center gap-2 bg-[var(--color-grove-pink)] text-white px-8 py-3 rounded-full text-xs font-black uppercase tracking-widest hover:bg-[var(--color-grove-pink)]/90 transition-all disabled:opacity-50 disabled:cursor-not-allowed shadow-lg shadow-[var(--color-grove-pink)]/20 active:scale-95"
                >
                  {isSavingNote ? <Loader2 className="animate-spin" size={16} /> : <Save size={16} />}
                  Save Note
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
