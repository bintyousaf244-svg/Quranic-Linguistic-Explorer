import React, { useState } from 'react';
import { Search, Loader2, X, Languages } from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import { searchWordDefinitionStream } from '../services/geminiService';
import { AnalysisCache } from '../services/cacheService';

interface WordSearchProps {
  onClose: () => void;
}

export const WordSearch: React.FC<WordSearchProps> = ({ onClose }) => {
  const [query, setQuery] = useState('');
  const [result, setResult] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim()) return;

    // Check cache first
    const cached = AnalysisCache.getWord(query.trim());
    if (cached) {
      setResult(cached);
      return;
    }

    setIsLoading(true);
    setResult('');
    try {
      let fullText = '';
      await searchWordDefinitionStream(query, (text) => {
        fullText = text;
        setResult(text);
      });
      
      if (fullText) {
        AnalysisCache.setWord(query.trim(), fullText);
      }
    } catch (error) {
      console.error(error);
      setResult('Failed to fetch definition. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-[var(--color-grove-paper)] w-full max-w-2xl rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[85vh] border border-[var(--color-grove-purple)]/10">
        {/* Header */}
        <div className="p-6 border-b border-[var(--color-grove-paper)] flex items-center justify-between bg-[var(--color-grove-paper)] sticky top-0 z-10">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-[var(--color-grove-purple)] flex items-center justify-center text-white shadow-lg shadow-[var(--color-grove-purple)]/20">
              <Languages size={20} />
            </div>
            <div>
              <h2 className="text-lg font-bold text-[var(--color-grove-purple)]">Global Dictionary</h2>
              <p className="text-xs text-[var(--color-grove-purple)]/60">Search any Arabic word for English meanings</p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-2 hover:bg-[var(--color-grove-paper)] rounded-full text-[var(--color-grove-purple)]/40 hover:text-[var(--color-grove-purple)] transition-all"
          >
            <X size={20} />
          </button>
        </div>

        {/* Search Bar */}
        <div className="p-6 bg-[var(--color-grove-cream)]">
          <form onSubmit={handleSearch} className="relative">
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Type an Arabic word (e.g., رحمن)..."
              className="w-full pl-12 pr-4 py-4 bg-[var(--color-grove-paper)] border border-[var(--color-grove-purple)]/10 rounded-2xl focus:ring-2 focus:ring-[var(--color-grove-purple)]/20 focus:border-[var(--color-grove-purple)]/30 outline-none transition-all text-lg font-arabic dir-rtl shadow-sm"
              autoFocus
            />
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-[var(--color-grove-purple)]/30" size={20} />
            <button
              type="submit"
              disabled={isLoading || !query.trim()}
              className="absolute right-2 top-1/2 -translate-y-1/2 bg-[var(--color-grove-green)] text-white px-6 py-2 rounded-xl text-sm font-medium hover:bg-[var(--color-grove-green)]/90 shadow-md shadow-[var(--color-grove-green)]/20 transition-all disabled:opacity-50"
            >
              {isLoading ? <Loader2 className="animate-spin" size={18} /> : 'Search'}
            </button>
          </form>
        </div>

        {/* Results */}
        <div className="flex-1 overflow-y-auto p-6 md:p-8 bg-[var(--color-grove-paper)]">
          {result ? (
            <>
              <div className="markdown-body prose prose-sm max-w-none prose-headings:text-[var(--color-grove-purple)] prose-strong:text-[var(--color-grove-purple)] prose-a:text-[var(--color-grove-teal)]">
                <ReactMarkdown>{result}</ReactMarkdown>
              </div>
              <div className="mt-8 pt-4 border-t border-[var(--color-grove-paper)] text-[10px] text-[var(--color-grove-purple)]/40 italic">
                Definitions cross-referenced with Lisan al-Arab, Al-Qamus al-Muhit, and Lane's Lexicon.
              </div>
            </>
          ) : !isLoading ? (
            <div className="h-full flex flex-col items-center justify-center text-center py-12">
              <div className="w-16 h-16 rounded-3xl bg-[var(--color-grove-paper)] flex items-center justify-center text-[var(--color-grove-purple)]/20 mb-4">
                <Search size={32} />
              </div>
              <p className="text-[var(--color-grove-purple)]/40 max-w-xs text-sm">
                Enter an Arabic word above to see its detailed English and Arabic definitions.
              </p>
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center py-12 gap-3">
              <Loader2 className="animate-spin text-[var(--color-grove-purple)]" size={32} />
              <p className="text-sm text-[var(--color-grove-purple)]/60">Searching dictionary...</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
