import React, { useEffect, useState } from 'react';
import { Surah, SurahDetail, Note } from '../types';
import { getSurahDetail } from '../services/quranService';
import { AyahCard } from './AyahCard';
import { Loader2, ArrowLeft, ArrowUp } from 'lucide-react';

interface SurahViewProps {
  surah: Surah;
  onBack: () => void;
  notes: Note[];
  onSaveNote: (surahNumber: number, ayahNumber: number, content: string) => Promise<void>;
  isAuthenticated: boolean;
  fontSize: number;
}

export const SurahView: React.FC<SurahViewProps> = ({ 
  surah, 
  onBack, 
  notes, 
  onSaveNote, 
  isAuthenticated,
  fontSize
}) => {
  const [detail, setDetail] = useState<SurahDetail | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [showScrollTop, setShowScrollTop] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setShowScrollTop(window.scrollY > 500);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  useEffect(() => {
    const fetchDetail = async () => {
      setIsLoading(true);
      try {
        const data = await getSurahDetail(surah.number);
        setDetail(data);
      } catch (error) {
        console.error(error);
      } finally {
        setIsLoading(false);
      }
    };
    fetchDetail();
  }, [surah.number]);

  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-center py-24 gap-4">
        <Loader2 className="animate-spin text-[var(--color-grove-purple)]" size={32} />
        <p className="text-[var(--color-grove-purple)]/60 font-medium">Loading Surah {surah.englishName}...</p>
      </div>
    );
  }

  if (!detail) return null;

  return (
    <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
      {/* Surah Header */}
      <div className="mb-12 text-center relative bg-[var(--color-grove-paper)] rounded-[2rem] p-12 shadow-sm border border-[var(--color-grove-purple)]/5">
        <button 
          onClick={onBack}
          className="absolute left-6 top-12 p-3 hover:bg-[var(--color-grove-cream)] rounded-full transition-all text-[var(--color-grove-purple)]"
        >
          <ArrowLeft size={24} />
        </button>
        
        <div className="inline-block px-4 py-1 bg-[var(--color-grove-gold)]/10 rounded-full text-[10px] font-bold uppercase tracking-[0.2em] text-[var(--color-grove-gold)] mb-6">
          Surah {surah.number}
        </div>
        <h2 className="text-5xl font-bold tracking-tight mb-3 text-[var(--color-grove-purple)]">{surah.englishName}</h2>
        <p className="text-[var(--color-grove-purple)]/50 text-xl mb-8 font-medium">{surah.englishNameTranslation}</p>
        
        <div className="text-6xl font-arabic text-[var(--color-grove-purple)] mb-10">
          {surah.name}
        </div>

        {surah.number !== 1 && surah.number !== 9 && (
          <div className="text-4xl font-arabic text-[var(--color-grove-green)] py-10 border-y border-[var(--color-grove-purple)]/5 mb-4">
            بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ
          </div>
        )}
      </div>

      {/* Ayahs */}
      <div className="max-w-4xl mx-auto">
        {detail.ayahs.map((ayah) => (
          <AyahCard
            key={ayah.number}
            ayah={ayah}
            surahName={surah.englishName}
            note={notes.find(n => n.surahNumber === surah.number && n.ayahNumber === ayah.numberInSurah)}
            onSaveNote={(content) => onSaveNote(surah.number, ayah.numberInSurah, content)}
            isAuthenticated={isAuthenticated}
            fontSize={fontSize}
          />
        ))}
      </div>

      {/* Scroll to Top Button */}
      {showScrollTop && (
        <button
          onClick={scrollToTop}
          className="fixed bottom-8 right-8 p-4 bg-[var(--color-grove-purple)] text-white rounded-full shadow-2xl hover:bg-[var(--color-grove-purple)]/90 transition-all animate-in fade-in zoom-in duration-300 z-50"
        >
          <ArrowUp size={24} />
        </button>
      )}
    </div>
  );
};
