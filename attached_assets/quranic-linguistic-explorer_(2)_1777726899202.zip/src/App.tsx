/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Layout } from './components/Layout';
import { SurahList } from './components/SurahList';
import { SurahView } from './components/SurahView';
import { WordSearch } from './components/WordSearch';
import { getAllSurahs } from './services/quranService';
import { Surah, Note } from './types';
import { Loader2, BookOpen } from 'lucide-react';
import { auth, signIn, logOut, onAuthStateChanged, db, collection, query, where, onSnapshot, addDoc, serverTimestamp, updateDoc, doc, getDocs, handleFirestoreError, OperationType } from './services/firebase';
import { getDocFromServer } from 'firebase/firestore';

export default function App() {
  const [surahs, setSurahs] = useState<Surah[]>([]);
  const [filteredSurahs, setFilteredSurahs] = useState<Surah[]>([]);
  const [selectedSurah, setSelectedSurah] = useState<Surah | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [user, setUser] = useState<any>(null);
  const [notes, setNotes] = useState<Note[]>([]);
  const [isAuthReady, setIsAuthReady] = useState(false);
  const [fontSize, setFontSize] = useState(32); // Default font size in px
  const [isDictionaryOpen, setIsDictionaryOpen] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState(() => {
    const saved = localStorage.getItem('darkMode');
    return saved ? JSON.parse(saved) : false;
  });

  // Apply dark mode
  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
    localStorage.setItem('darkMode', JSON.stringify(isDarkMode));
  }, [isDarkMode]);

  // Connection Test
  useEffect(() => {
    async function testConnection() {
      try {
        await getDocFromServer(doc(db, 'test', 'connection'));
      } catch (error) {
        if(error instanceof Error && error.message.includes('the client is offline')) {
          console.error("Please check your Firebase configuration. ");
        }
      }
    }
    testConnection();
  }, []);

  // Fetch Surahs
  useEffect(() => {
    const fetchSurahs = async () => {
      try {
        const data = await getAllSurahs();
        setSurahs(data);
        setFilteredSurahs(data);
      } catch (error) {
        console.error("Failed to fetch surahs:", error);
      } finally {
        setIsLoading(false);
      }
    };
    fetchSurahs();
  }, []);

  // Auth State
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
      setIsAuthReady(true);
    });
    return () => unsubscribe();
  }, []);

  // Fetch Notes
  useEffect(() => {
    if (!user) {
      setNotes([]);
      return;
    }

    const q = query(collection(db, 'notes'), where('userId', '==', user.uid));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const notesData = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Note[];
      setNotes(notesData);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'notes');
    });

    return () => unsubscribe();
  }, [user]);

  const handleSearch = (query: string) => {
    const filtered = surahs.filter(s => 
      s.englishName.toLowerCase().includes(query.toLowerCase()) ||
      s.name.includes(query) ||
      s.number.toString() === query
    );
    setFilteredSurahs(filtered);
  };

  const handleSaveNote = async (surahNumber: number, ayahNumber: number, content: string) => {
    if (!user) return;

    const existingNote = notes.find(n => n.surahNumber === surahNumber && n.ayahNumber === ayahNumber);

    try {
      if (existingNote?.id) {
        const noteRef = doc(db, 'notes', existingNote.id);
        await updateDoc(noteRef, {
          content,
          updatedAt: serverTimestamp()
        });
      } else {
        await addDoc(collection(db, 'notes'), {
          userId: user.uid,
          surahNumber,
          ayahNumber,
          content,
          createdAt: serverTimestamp()
        });
      }
    } catch (error) {
      handleFirestoreError(error, existingNote?.id ? OperationType.UPDATE : OperationType.CREATE, 'notes');
    }
  };

  return (
    <Layout 
      onSearch={handleSearch} 
      onOpenDictionary={() => setIsDictionaryOpen(true)}
      user={user} 
      onSignIn={signIn} 
      onSignOut={logOut}
      fontSize={fontSize}
      onFontSizeChange={setFontSize}
      isDarkMode={isDarkMode}
      onToggleDarkMode={() => setIsDarkMode(!isDarkMode)}
    >
      {isDictionaryOpen && <WordSearch onClose={() => setIsDictionaryOpen(false)} />}
      {isLoading ? (
        <div className="flex flex-col items-center justify-center py-32 gap-4">
          <Loader2 className="animate-spin text-[var(--color-grove-green)]" size={40} />
          <p className="text-[var(--color-grove-purple)]/60 font-bold uppercase tracking-widest text-xs">Preparing the Quranic Library...</p>
        </div>
      ) : selectedSurah ? (
        <SurahView 
          surah={selectedSurah} 
          onBack={() => setSelectedSurah(null)}
          notes={notes}
          onSaveNote={handleSaveNote}
          isAuthenticated={!!user}
          fontSize={fontSize}
        />
      ) : (
        <div className="space-y-12">
          {/* Hero Section */}
          <div className="text-center max-w-2xl mx-auto py-12">
            <h2 className="text-5xl font-bold tracking-tight mb-6 text-[var(--color-grove-purple)]">Explore the Divine Word</h2>
            <p className="text-[var(--color-grove-purple)]/70 text-lg leading-relaxed font-medium">
              Deep dive into the linguistic miracles of the Quran with Usmani script, 
              detailed grammar analysis, and morphological breakdowns.
            </p>
          </div>

          {/* Surah Grid */}
          <div className="bg-[var(--color-grove-paper)] rounded-[2rem] p-8 shadow-sm border border-[var(--color-grove-purple)]/5">
            <div className="flex items-center gap-3 mb-8 border-b border-[var(--color-grove-purple)]/10 pb-6">
              <div className="p-2 bg-[var(--color-grove-teal)]/10 rounded-lg">
                <BookOpen size={24} className="text-[var(--color-grove-teal)]" />
              </div>
              <h3 className="text-xl font-bold uppercase tracking-widest text-[var(--color-grove-purple)]">Surahs</h3>
            </div>
            <SurahList 
              surahs={filteredSurahs} 
              onSelect={setSelectedSurah} 
              selectedSurahNumber={selectedSurah?.number}
            />
          </div>
        </div>
      )}
    </Layout>
  );
}
