import { Surah, SurahDetail } from "../types";

const BASE_URL = "https://api.alquran.cloud/v1";

export async function getAllSurahs(): Promise<Surah[]> {
  // Try to get from cache first
  const cached = localStorage.getItem('quran_surahs_list');
  if (cached) {
    return JSON.parse(cached);
  }

  const response = await fetch(`${BASE_URL}/surah`);
  const data = await response.json();
  
  // Save to cache
  localStorage.setItem('quran_surahs_list', JSON.stringify(data.data));
  
  return data.data;
}

export async function getSurahDetail(surahNumber: number): Promise<SurahDetail> {
  // Try to get from session cache first
  const cacheKey = `quran_surah_${surahNumber}_v2`; // Versioned cache key
  const cached = sessionStorage.getItem(cacheKey);
  if (cached) {
    return JSON.parse(cached);
  }

  // Fetch multiple editions: Uthmani (Arabic), Sahih International (English), Jalandhry (Urdu), Jalalayn (Arabic Tafsir)
  const response = await fetch(`${BASE_URL}/surah/${surahNumber}/editions/quran-uthmani,en.sahih,ur.jalandhry,ar.jalalayn`);
  const data = await response.json();
  
  if (!data.data || data.data.length < 4) {
    throw new Error("Failed to fetch all translations");
  }

  const uthmani = data.data[0];
  const english = data.data[1];
  const urdu = data.data[2];
  const tafsir = data.data[3];

  // Merge translations into the uthmani ayahs
  const mergedAyahs = uthmani.ayahs.map((ayah: any, index: number) => ({
    ...ayah,
    translations: {
      en: english.ayahs[index].text,
      ur: urdu.ayahs[index].text,
      ar: tafsir.ayahs[index].text
    }
  }));

  const result: SurahDetail = {
    ...uthmani,
    ayahs: mergedAyahs
  };
  
  // Save to session cache
  sessionStorage.setItem(cacheKey, JSON.stringify(result));
  
  return result;
}
