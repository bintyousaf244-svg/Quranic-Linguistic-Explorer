/**
 * Simple caching service for AI analysis results
 * Uses localStorage to persist results across sessions
 */

const CACHE_PREFIX = 'quran_analysis_';

export const AnalysisCache = {
  get: (type: string, surahName: string, ayahNumber: number): string | null => {
    const key = `${CACHE_PREFIX}${type}_${surahName}_${ayahNumber}`;
    return localStorage.getItem(key);
  },

  set: (type: string, surahName: string, ayahNumber: number, content: string): void => {
    const key = `${CACHE_PREFIX}${type}_${surahName}_${ayahNumber}`;
    localStorage.setItem(key, content);
  },

  // For the global dictionary search
  getWord: (word: string): string | null => {
    const key = `${CACHE_PREFIX}word_${word}`;
    return localStorage.getItem(key);
  },

  setWord: (word: string, content: string): void => {
    const key = `${CACHE_PREFIX}word_${word}`;
    localStorage.setItem(key, content);
  }
};
