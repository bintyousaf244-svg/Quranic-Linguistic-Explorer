import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export async function getAyahGrammarStream(ayahText: string, surahName: string, ayahNumber: number, onChunk: (text: string) => void) {
  const response = await ai.models.generateContentStream({
    model: "gemini-3-flash-preview",
    contents: `Act as an expert in Quranic Arabic Grammar (I'rab). 
    Analyze the following ayah from Surah ${surahName}, Ayah ${ayahNumber}:
    
    "${ayahText}"
    
    Your analysis MUST be based on authentic classical sources such as:
    - "I'rab al-Quran wa Bayanuhu" by Muhyi al-Din al-Darwish
    - "Al-Tableel al-Nahwi" by Al-Zajjaj
    - "I'rab al-Quran" by Al-Nahhas
    
    Provide the analysis in Arabic. Include the I'rab of each word/phrase. 
    At the end, briefly mention the scholarly works this analysis aligns with.`,
    config: {
      temperature: 0.1,
    },
  });

  let fullText = "";
  for await (const chunk of response) {
    fullText += chunk.text;
    onChunk(fullText);
  }
  return fullText;
}

export async function getAyahDictionaryStream(ayahText: string, surahName: string, ayahNumber: number, onChunk: (text: string) => void) {
  const response = await ai.models.generateContentStream({
    model: "gemini-3-flash-preview",
    contents: `Act as a Quranic Lexicographer. For the following ayah from Surah ${surahName}, Ayah ${ayahNumber}:
    
    "${ayahText}"
    
    Provide a word-by-word breakdown based on authentic linguistic sources like "Lisan al-Arab", "Mu'jam Maqayis al-Lugha", and "Al-Mufradat fi Gharib al-Quran" by Al-Raghib al-Asfahani.
    
    For each word:
    1. Arabic Word
    2. English Meaning (Contextual)
    3. Arabic Meaning (Scholarly definition)
    4. Root (Jidhr) and its core meaning
    
    Format as a clean table.`,
    config: {
      temperature: 0.1,
    },
  });

  let fullText = "";
  for await (const chunk of response) {
    fullText += chunk.text;
    onChunk(fullText);
  }
  return fullText;
}

export async function getAyahMorphologyStream(ayahText: string, surahName: string, ayahNumber: number, onChunk: (text: string) => void) {
  const response = await ai.models.generateContentStream({
    model: "gemini-3-flash-preview",
    contents: `Act as an expert in Arabic Morphology (Sarf). 
    Analyze the following ayah from Surah ${surahName}, Ayah ${ayahNumber}:
    
    "${ayahText}"
    
    Your analysis MUST follow the methodology of classical Sarf scholars (e.g., Ibn Jinni, Al-Hamalawy).
    
    For each major word, provide:
    1. Root (Jidhr)
    2. Verb Form (Wazn) / Noun Type
    3. Sarf Saghir (صرف صغير)
    4. Sarf Kabir (صرف كبير) for the specific form used.
    
    Provide the analysis in Arabic. Mention the linguistic weight (Wazn) clearly.`,
    config: {
      temperature: 0.1,
    },
  });

  let fullText = "";
  for await (const chunk of response) {
    fullText += chunk.text;
    onChunk(fullText);
  }
  return fullText;
}

export async function searchWordDefinitionStream(word: string, onChunk: (text: string) => void) {
  const response = await ai.models.generateContentStream({
    model: "gemini-3-flash-preview",
    contents: `Act as a rigorous Arabic-English Dictionary. 
    Provide a detailed definition for the word: "${word}"
    
    Your data MUST be cross-referenced with:
    - "Lisan al-Arab" by Ibn Manzur
    - "Al-Qamus al-Muhit" by Al-Fayruzabadi
    - "Lane's Lexicon" (for English accuracy)
    
    Include:
    1. English meanings
    2. Arabic synonyms and classical definitions
    3. Root word and its primary semantic field
    4. Quranic usage examples (if applicable)
    
    Format with Markdown.`,
    config: {
      temperature: 0.1,
    },
  });

  let fullText = "";
  for await (const chunk of response) {
    fullText += chunk.text;
    onChunk(fullText);
  }
  return fullText;
}
